Olio-ohjelmoinnin harjoitustyö, jossa käsitellään tekstitiedostoja. 
Ohjelma kysyy käyttäjältä erilaisia komentoja, jotka mm. lisäävät, poistavat ja tulostavat erilaisia dokumentteja kokoelmaan. 